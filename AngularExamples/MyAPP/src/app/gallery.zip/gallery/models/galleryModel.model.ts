export class GalleryModel
    {
         Id:number;
         Filepath:string;
         Alt:string;
         constructor(){
              this.Id=0;
              this.Filepath="";
              this.Alt="";
         }
    }